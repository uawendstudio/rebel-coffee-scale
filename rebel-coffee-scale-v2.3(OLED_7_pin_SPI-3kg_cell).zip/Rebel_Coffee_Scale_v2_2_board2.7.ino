#include <Arduino.h>
#include <U8g2lib.h>
#include <Wire.h>
#include <SPI.h>
#include <EEPROM.h>
#include "SparkFun_Qwiic_Scale_NAU7802_Arduino_Library.h"
#include "hardware/gpio.h"
#include "hardware/xosc.h"
#include "localization.h"

/*
    Version 2.31 
    - Added 200 g factory calibration
*/


// SCREEN SSD1309 2.42" SPI
U8G2_SSD1309_128X64_NONAME0_F_4W_HW_SPI u8g2(U8G2_R2, 17, 16, 20);

NAU7802 myScale;

// Language flag: false = EN, true = UA
bool isUkrainian = false;

// Hardware base zero offset (set at startup/calibration for overload protection)
int32_t hardwareZeroOffset = 0;

// Auto-Sleep options: 0 = 10m, 1 = 20m, 2 = 1h, 3 = Off
uint8_t autoSleepIndex = 1; // Default: 20m

// Returns timeout in milliseconds, or 0 if disabled
unsigned long getSleepTimeoutMs()
{
  switch (autoSleepIndex)
  {
  case 0:
    return 600000UL; // 10 minutes
  case 1:
    return 1200000UL; // 20 minutes
  case 2:
    return 3600000UL; // 1 hour
  case 3:
    return 0UL; // Disabled
  default:
    return 1200000UL;
  }
}

// Physical button pins (0=Pin7, 1=Pin8, 2=Pin6)
const int buttonPins[3] = {7, 8, 6};
const int BATTERY_PIN = 28;

enum Action
{
  ACTION_TIME = 0,
  ACTION_AUTO = 1,
  ACTION_TARE = 2
};
int userMapping[3] = {0, 1, 2};

enum TareState
{
  TARE_IDLE,
  TARE_SETTLING,   // Waiting for physical mechanical button vibrations to stop
  TARE_CALCULATING // Sampling NAU7802 scale readings
};

TareState currentTareState = TARE_IDLE;
unsigned long tarePhaseStartTime = 0;
const unsigned long TARE_SETTLING_DELAY_MS = 150; // For stability of reading

enum ScaleState
{
  STATE_SCALE,
  STATE_MENU_HOME,
  STATE_CONFIRM_DEFAULTS,
  STATE_MAP_TARE,
  STATE_MAP_AUTO,
  STATE_MAP_TIME,
  STATE_CONFIRM_CALIBRATION,
  STATE_CAL_STEP1_EMPTY,
  STATE_CAL_STEP2_PLACE_WT,
  STATE_CAL_STEP3_MEASURE,
  STATE_CAL_DONE
};
ScaleState currentState = STATE_SCALE;

int menuIndex = 0; // List of 10: 0..9
bool isLbs = false;
bool isNiMH = false;
bool tareResetsTimer = true; // TRUE = RESET (Time+Weight+Auto), FALSE = TARE (Weight only)

// Measuring / Filter mode options: 0 = Smooth, 1 = Jittery, 2 = Auto Profile
uint8_t measuringModeIndex = 0;

// Filter Profile Structure for DRY implementation
struct FilterProfile
{
  float nearZeroWeightMax;    // Max absolute weight considered "near zero"
  float nearZeroDiffMax;      // Max delta change to trigger near-zero smoothing
  float nearZeroAlpha;        // Weight blending factor near zero (lower = smoother)
  float midDiffMax;           // Max delta change for standard filtering tier
  float midAlpha;             // Standard tier weight blending factor
  float zeroLowerBound;       // Lower deadband bound for clamping to 0.00
  float zeroUpperBound;       // Upper deadband bound for clamping to 0.00
};

// Adjustable filter presets (Index 0: Smooth, Index 1: Jittery, Index 2: Auto)
const FilterProfile filterProfiles[3] = {
  // 1. SMOOTH Profile (Default)
  {
    .nearZeroWeightMax = 0.25f,
    .nearZeroDiffMax   = 0.25f,
    .nearZeroAlpha     = 0.25f,
    .midDiffMax        = 0.80f,
    .midAlpha          = 0.10f,
    .zeroLowerBound    = -0.15f,
    .zeroUpperBound    = 0.05f
  },
  // 2. JITTERY Profile
  {
    .nearZeroWeightMax = 0.25f,
    .nearZeroDiffMax   = 0.25f,
    .nearZeroAlpha     = 0.40f,  // Adjust here
    .midDiffMax        = 0.80f,
    .midAlpha          = 0.30f,  // Adjust here
    .zeroLowerBound    = -0.15f,
    .zeroUpperBound    = 0.05f
  },
  // 3. AUTO Profile (3rd set of values)
  {
    .nearZeroWeightMax = 0.25f,
    .nearZeroDiffMax   = 0.25f,
    .nearZeroAlpha     = 0.40f,  // Adjust here
    .midDiffMax        = 0.80f,
    .midAlpha          = 0.15f,  // Adjust here
    .zeroLowerBound    = -0.45f,
    .zeroUpperBound    = 0.03f
  }
};

unsigned long lastActivityTime = 0;

void enterDeepSleep();
void setOledBrightness(uint8_t mode);
void drawUI();
void loadSettings();
void saveSettings();
inline void resetInactivityTimer() { lastActivityTime = millis(); }

// Time and weight

float factoryCalibrationFactor = 674.78003f;
float calibrationFactor = factoryCalibrationFactor;
float displayWeight = 0.00;
unsigned long timerStartMillis = 0;
bool timerRunning = false;
bool autoStartEnabled = false;

// Dynamic absolute weight tracking for overload protection
float absoluteWeightGrams = 0.0f;

enum BatteryDisplayMode
{
  BAT_SHOW_VOLTS = 0,
  BAT_SHOW_PCT = 1,
  BAT_SHOW_BOTH = 2
};

uint8_t batteryDisplayMode = BAT_SHOW_BOTH;

float smoothedBatteryV = 3.00;
const float VOLTAGE_CORRECTION = 1.001543;
unsigned long lastBatteryCheck = 0;
bool batteryInitialized = false;

float readStabilizedBatteryVoltage()
{
  analogRead(BATTERY_PIN);
  delayMicroseconds(50);

  uint32_t adcSum = 0;
  for (int i = 0; i < 32; i++)
  {
    adcSum += analogRead(BATTERY_PIN);
    delayMicroseconds(100);
  }

  float avgRaw = (float)adcSum / 32.0f;
  return (avgRaw / 4095.0f) * 3.3f * (14.7f / 4.7f) * VOLTAGE_CORRECTION;
}

unsigned long lastDisplayUpdate = 0;
const int DISPLAY_INTERVAL = 40;

unsigned long lastDebounceTime[3] = {0, 0, 0};
bool buttonState[3] = {HIGH, HIGH, HIGH};
bool lastStableButtonState[3] = {HIGH, HIGH, HIGH};
const unsigned long DEBOUNCE_DELAY = 40;
unsigned long menuEnteredTime = 0;

const uint8_t contrastValues[6] = {1, 5, 10, 20, 30, 40};
uint8_t contrastIndex = 3;

void setup()
{
  set_sys_clock_khz(48000, true);

  Wire.setSDA(12);
  Wire.setSCL(13);
  Wire.begin();
  Wire.setClock(100000);  // 100kHz standard I2C stability
  Wire.setTimeout(20000); // 20ms hardware timeout for I2C operations
  SPI.begin();

  u8g2.begin();

  loadSettings();

  // Check if a permanent factory calibration has been locked in
    uint8_t factoryFlagSet = EEPROM.read(40);
    if (factoryFlagSet == 0xA5) 
    {
        // Load the locked factory calibration from EEPROM
        EEPROM.get(41, factoryCalibrationFactor);
    }
    else
    {
        // Fresh board fallback default before any calibration has occurred
        factoryCalibrationFactor = 674.78003f; 
    }

  setOledBrightness(contrastIndex);
  u8g2.setContrast(contrastValues[contrastIndex]);

  for (int i = 0; i < 3; i++)
  {
    pinMode(buttonPins[i], INPUT_PULLUP);
  }
  analogReadResolution(12);

  if (myScale.begin(Wire))
  {
    myScale.setLDO(NAU7802_LDO_3V0);
    myScale.setGain(NAU7802_GAIN_128);
    myScale.setSampleRate(NAU7802_SPS_20);



    // Safely enable PGA_CAP_EN without breaking other bits in register 0x1C
    Wire.beginTransmission(0x2A);
    Wire.write(0x1C);
    Wire.endTransmission(false); // Restart condition
    
    Wire.requestFrom(0x2A, 1);
    if (Wire.available()) {
      uint8_t regVal = Wire.read();
      regVal |= (1 << 7); // Set PGA_CAP_EN bit (bit 7)
    




    Wire.beginTransmission(0x2A);
    Wire.write(0x1C);
    Wire.write(regVal);
    Wire.endTransmission();
  }

    myScale.calibrateAFE();
    myScale.calculateZeroOffset(4);
    hardwareZeroOffset = myScale.getZeroOffset();
  }
}

void loop()
{
  unsigned long now = millis();

  bool click7 = false;
  bool click8 = false;
  bool click6 = false;

  for (int i = 0; i < 3; i++)
  {
    bool rawReading = digitalRead(buttonPins[i]);

    if (rawReading != buttonState[i])
    {
      lastDebounceTime[i] = now;
      buttonState[i] = rawReading;
    }

    if ((now - lastDebounceTime[i]) > DEBOUNCE_DELAY)
    {
      if (rawReading != lastStableButtonState[i])
      {
        if (rawReading == LOW)
        {
          resetInactivityTimer();
          if (buttonPins[i] == 7)
            click7 = true;
          if (buttonPins[i] == 8)
            click8 = true;
          if (buttonPins[i] == 6 && currentState != STATE_SCALE)
            click6 = true;
        }
        lastStableButtonState[i] = rawReading;
      }
    }
  }

  unsigned long currentTimeout = getSleepTimeoutMs();
  if (currentTimeout > 0 && currentState == STATE_SCALE && (now - lastActivityTime >= currentTimeout))
  {
    enterDeepSleep();
  }

  // Pin 6 hold-to-enter-menu logic
  static unsigned long btn6DownTime = 0;
  static bool btn6WasPressed = false;
  static bool menuTriggered = false;

  if (currentState == STATE_SCALE)
  {
    bool pin6Reading = (digitalRead(6) == LOW);
    if (pin6Reading && !btn6WasPressed)
    {
      btn6DownTime = now;
      btn6WasPressed = true;
      menuTriggered = false;
    }
    else if (pin6Reading && btn6WasPressed && !menuTriggered)
    {
      if (now - btn6DownTime >= 600)
      {
        currentState = STATE_MENU_HOME;
        menuIndex = 0; // Index 0 (UNITS) will appear centered with LANG (Index 9) above it
        menuEnteredTime = now;
        menuTriggered = true;
        u8g2.clearBuffer();
      }
    }
    else if (!pin6Reading && btn6WasPressed)
    {
      if (!menuTriggered)
      {
        click6 = true; // Short click action (Tare/Time/Auto)
      }
      btn6WasPressed = false;
      menuTriggered = false;
    }
  }
  else
  {
    btn6WasPressed = false;
    menuTriggered = false;
  }

  if (currentState != STATE_SCALE && (now - menuEnteredTime < 300))
  {
    click6 = false;
    click7 = false;
    click8 = false;
  }

  // MENU LOGIC
  const LocalizedStrings &s = getStrings();
  if (currentState != STATE_SCALE)
  {
    // Special handling for Pin 7 hold-to-scroll-up feature in main menu home with action cooldown delays
    static unsigned long btn7DownTime = 0;
    static bool btn7WasPressed = false;
    static bool actionTriggered = false;
    static unsigned long lastActionTime = 0;
    const unsigned long actionCooldown = 250; // Minimum ms between menu movements

    if (currentState == STATE_MENU_HOME)
    {
      bool pin7Reading = (digitalRead(7) == LOW);
      if (pin7Reading && !btn7WasPressed)
      {
        btn7DownTime = now;
        btn7WasPressed = true;
        actionTriggered = false;
      }
      else if (pin7Reading && btn7WasPressed && !actionTriggered)
      {
        // Scroll UP on long hold (>= 300ms), protected by cooldown
        if ((now - btn7DownTime >= 300) && (now - lastActionTime >= actionCooldown))
        {
          menuIndex = (menuIndex - 1 + 10) % 10; 
          actionTriggered = true;
          lastActionTime = now;
        }
      }
      else if (!pin7Reading && btn7WasPressed)
      {
        // Scroll DOWN on short release, protected by cooldown
        if (!actionTriggered)
        {
          if (now - lastActionTime >= actionCooldown)
          {
            menuIndex = (menuIndex + 1) % 10;
            lastActionTime = now;
          }
        }
        btn7WasPressed = false;
        actionTriggered = false;
        click7 = false;
      }
    }
    else
    {
      btn7WasPressed = false;
      actionTriggered = false;
    }

    if (currentState == STATE_CAL_DONE)
    {
      u8g2.clearBuffer();
      u8g2.setFont(s.fontMain);
      drawText(u8g2, 0, 32, s.calibrated);
      u8g2.sendBuffer();

      delay(1200);
      currentState = STATE_MENU_HOME;
      menuEnteredTime = now;
      u8g2.clearBuffer();
    }
    else if (currentState == STATE_MENU_HOME)
    {
      if (click6)
      {
        if (menuIndex == 0)
          isLbs = !isLbs;
        else if (menuIndex == 1)
          isNiMH = !isNiMH;
        else if (menuIndex == 2)
          tareResetsTimer = !tareResetsTimer;
        else if (menuIndex == 3)
        {
          contrastIndex = (contrastIndex + 1) % 6;
          setOledBrightness(contrastIndex);
        }
        else if (menuIndex == 4)
        {
          currentState = STATE_CONFIRM_DEFAULTS;
          u8g2.clearBuffer();
        }
        else if (menuIndex == 5)
        {
          currentState = STATE_CONFIRM_CALIBRATION;
          u8g2.clearBuffer();
        }
        else if (menuIndex == 6)
        {
          batteryDisplayMode = (batteryDisplayMode + 1) % 5;
        }
        else if (menuIndex == 7)
        {
          autoSleepIndex = (autoSleepIndex + 1) % 4;
        }
        else if (menuIndex == 8)
        {
          measuringModeIndex = (measuringModeIndex + 1) % 2; // Cycle: Smooth <-> Jittery only
        }
        else if (menuIndex == 9)
        {
          isUkrainian = !isUkrainian;
        }
      }
      else if (click8)
      {
        saveSettings();
        currentState = STATE_SCALE;
        u8g2.clearBuffer();
      }
    }
    else if (currentState == STATE_CONFIRM_CALIBRATION)
    {
      if (click7)
      {
        calibrationFactor = factoryCalibrationFactor;
        saveSettings();
        u8g2.clearBuffer();
        u8g2.setFont(s.fontMain);
        drawText(u8g2, 0, 32, s.restored);
        u8g2.sendBuffer();
        delay(1000);
        currentState = STATE_MENU_HOME;
        menuEnteredTime = now;
        u8g2.clearBuffer();
      }
      else if (click6)
      {
        currentState = STATE_CAL_STEP1_EMPTY;
        u8g2.clearBuffer();
      }
      else if (click8)
      {
        currentState = STATE_MENU_HOME;
        u8g2.clearBuffer();
      }
    }
    else if (currentState == STATE_CONFIRM_DEFAULTS)
    {
      if (click7)
      {
        userMapping[ACTION_TARE] = -1;
        userMapping[ACTION_AUTO] = -1;
        userMapping[ACTION_TIME] = -1;
        currentState = STATE_MAP_TARE;
        u8g2.clearBuffer();
      }
      else if (click6)
      {
        userMapping[ACTION_TIME] = 0;
        userMapping[ACTION_AUTO] = 1;
        userMapping[ACTION_TARE] = 2;
        currentState = STATE_MENU_HOME;
        u8g2.clearBuffer();
      }
      else if (click8)
      {
        currentState = STATE_MENU_HOME;
        u8g2.clearBuffer();
      }
    }
    else if (currentState == STATE_MAP_TARE)
    {
      if (click7)
      {
        userMapping[ACTION_TARE] = 0;
        currentState = STATE_MAP_AUTO;
        u8g2.clearBuffer();
      }
      else if (click8)
      {
        userMapping[ACTION_TARE] = 1;
        currentState = STATE_MAP_AUTO;
        u8g2.clearBuffer();
      }
      else if (click6)
      {
        userMapping[ACTION_TARE] = 2;
        currentState = STATE_MAP_AUTO;
        u8g2.clearBuffer();
      }
    }
    else if (currentState == STATE_MAP_AUTO)
    {
      if (click7 && userMapping[ACTION_TARE] != 0)
      {
        userMapping[ACTION_AUTO] = 0;
        currentState = STATE_MAP_TIME;
        u8g2.clearBuffer();
      }
      else if (click8 && userMapping[ACTION_TARE] != 1)
      {
        userMapping[ACTION_AUTO] = 1;
        currentState = STATE_MAP_TIME;
        u8g2.clearBuffer();
      }
      else if (click6 && userMapping[ACTION_TARE] != 2)
      {
        userMapping[ACTION_AUTO] = 2;
        currentState = STATE_MAP_TIME;
        u8g2.clearBuffer();
      }
    }
    else if (currentState == STATE_MAP_TIME)
    {
      for (int i = 0; i < 3; i++)
      {
        if (userMapping[ACTION_TARE] != i && userMapping[ACTION_AUTO] != i)
        {
          userMapping[ACTION_TIME] = i;
        }
      }
      currentState = STATE_MENU_HOME;
      u8g2.clearBuffer();
    }
    else if (currentState == STATE_CAL_STEP1_EMPTY)
    {
      if (click6)
      {
        u8g2.clearBuffer();
        u8g2.setFont(s.fontMain);
        drawText(u8g2, 0, 32, s.settling);
        u8g2.sendBuffer();

        delay(800);
        while (myScale.available())
        {
          myScale.getReading();
        }

        long rawZero = 0;
        int samplesZero = 0;
        unsigned long calTimeout = millis();

        while (samplesZero < 30 && (millis() - calTimeout < 2500))
        {
          if (myScale.available())
          {
            rawZero += myScale.getReading();
            samplesZero++;
          }
          delay(10);
        }

        if (samplesZero > 0)
        {
          int32_t zOffset = rawZero / samplesZero;
          myScale.setZeroOffset(zOffset);
          hardwareZeroOffset = zOffset;
        }

        currentState = STATE_CAL_STEP2_PLACE_WT;
        menuEnteredTime = now;
        u8g2.clearBuffer();
      }
      else if (click8)
      {
        currentState = STATE_MENU_HOME;
        menuEnteredTime = now;
        u8g2.clearBuffer();
      }
    }
    else if (currentState == STATE_CAL_STEP2_PLACE_WT)
    {
      if (click6)
      {
        currentState = STATE_CAL_STEP3_MEASURE;
        menuEnteredTime = now;
        u8g2.clearBuffer();
      }
      else if (click8)
      {
        currentState = STATE_MENU_HOME;
        menuEnteredTime = now;
        u8g2.clearBuffer();
      }
    }
    else if (currentState == STATE_CAL_STEP3_MEASURE)
    {
      u8g2.clearBuffer();
      u8g2.setFont(s.fontMain);
      drawText(u8g2, 0, 32, s.sampling);
      u8g2.sendBuffer();

      delay(1000);
      while (myScale.available())
      {
        myScale.getReading();
      }

      long rawWithWeight = 0;
      int samplesWeight = 0;
      unsigned long calTimeout = millis();

      while (samplesWeight < 60 && (millis() - calTimeout < 4000))
      {
        if (myScale.available())
        {
          rawWithWeight += myScale.getReading();
          samplesWeight++;
        }
        delay(5);
      }

      if (samplesWeight > 0)
      {
        rawWithWeight /= samplesWeight;
      }

      long rawZero = myScale.getZeroOffset();
      uint8_t factoryFlagSet = EEPROM.read(40);
      float newFactor;
      if (factoryFlagSet == 0xA5)
      {
          // regular calibration
          newFactor = (float)abs(rawWithWeight - rawZero) / 100.0f;
      }
      else {
          // factory calibration with 200 g
          newFactor = (float)abs(rawWithWeight - rawZero) / 200.0f;
      }

      if (newFactor > 10.0f)
      {
        calibrationFactor = newFactor;
        if (EEPROM.read(40) != 0xA5) 
        {
            EEPROM.write(40, 0xA5);
            EEPROM.put(41, calibrationFactor);
        }
        saveSettings();
        currentState = STATE_CAL_DONE;
      }
      else
      {
        currentState = STATE_MENU_HOME;
      }

      menuEnteredTime = now;
      u8g2.clearBuffer();
    }

    if (now - lastDisplayUpdate >= DISPLAY_INTERVAL)
    {
      lastDisplayUpdate = now;
      drawUI();
    }
    return;
  }

  bool tareActionClick = (userMapping[ACTION_TARE] == 0 ? click7 : (userMapping[ACTION_TARE] == 1 ? click8 : click6));
  bool timeActionClick = (userMapping[ACTION_TIME] == 0 ? click7 : (userMapping[ACTION_TIME] == 1 ? click8 : click6));
  bool autoActionClick = (userMapping[ACTION_AUTO] == 0 ? click7 : (userMapping[ACTION_AUTO] == 1 ? click8 : click6));

  if (tareActionClick && currentTareState == TARE_IDLE)
  {
    if (tareResetsTimer)
    {
      timerRunning = false;
      autoStartEnabled = false;
      timerStartMillis = 0;
    }
    resetInactivityTimer();
    currentTareState = TARE_SETTLING;
    tarePhaseStartTime = now;
  }

  switch (currentTareState)
  {
  case TARE_SETTLING:
    if (now - tarePhaseStartTime >= TARE_SETTLING_DELAY_MS)
    {
      currentTareState = TARE_CALCULATING;
    }
    break;

  case TARE_CALCULATING:
    while (myScale.available())
    {
      myScale.getReading();
    }
    myScale.calculateZeroOffset(4);
    displayWeight = 0.00f;
    currentTareState = TARE_IDLE;
    resetInactivityTimer();
    break;

  case TARE_IDLE:
  default:
    break;
  }

  if (timeActionClick)
  {
    if (timerRunning)
    {
      timerRunning = false;
      autoStartEnabled = false;
    }
    else
    {
      timerStartMillis = now;
      timerRunning = true;
      autoStartEnabled = false;
    }
  }

  if (autoActionClick)
  {
    myScale.calculateZeroOffset(4);
    displayWeight = 0;
    timerStartMillis = now;
    timerRunning = false;
    autoStartEnabled = true;
  }

  unsigned long batteryInterval = 30000;
  if (now - lastBatteryCheck >= batteryInterval)
  {
    lastBatteryCheck = now;
    float newSampleV = readStabilizedBatteryVoltage();

    if (!batteryInitialized)
    {
      smoothedBatteryV = newSampleV;
      batteryInitialized = true;
    }
    else
    {
      smoothedBatteryV = (smoothedBatteryV * 0.7f) + (newSampleV * 0.3f);
    }
  }

  // REFACTORED DRY WEIGHT SMOOTHING FILTER
  if (myScale.available())
  {
    long rawValue = 0;
    while (myScale.available())
    {
      rawValue = myScale.getReading();
    }

    absoluteWeightGrams = (float)(rawValue - hardwareZeroOffset) / calibrationFactor;
    float currentRawGrams = (float)(rawValue - myScale.getZeroOffset()) / calibrationFactor;
    float diff = abs(currentRawGrams - displayWeight);

    // If auto-start is active, use the dedicated Auto filter profile (index 2), otherwise use the user-selected profile
    uint8_t activeProfileIdx = autoStartEnabled ? 2 : measuringModeIndex;
    const FilterProfile &p = filterProfiles[activeProfileIdx];

    if (timerRunning || diff > 10.00f)
    {
      resetInactivityTimer();
    }
    
    if (abs(displayWeight) < p.nearZeroWeightMax && diff < p.nearZeroDiffMax)
    {
      displayWeight = (currentRawGrams * p.nearZeroAlpha) + (displayWeight * (1.0f - p.nearZeroAlpha));
    }
    else if (diff < 0.07f)
    {
      // Deadband stability hold
    }
    else if (diff < p.midDiffMax)
    {
      displayWeight = (currentRawGrams * p.midAlpha) + (displayWeight * (1.0f - p.midAlpha));
    }
    else
    {
      displayWeight = currentRawGrams;
    }

    if (displayWeight > p.zeroLowerBound && displayWeight < p.zeroUpperBound)
    {
      displayWeight = 0.00f;
    }

    if (autoStartEnabled && !timerRunning && displayWeight > 5.0f)
    {
      timerRunning = true;
      timerStartMillis = now;
    }
  }

  if (now - lastDisplayUpdate >= DISPLAY_INTERVAL)
  {
    lastDisplayUpdate = now;
    drawUI();
  }
}

void drawUI()
{
  u8g2.clearBuffer();
  const LocalizedStrings &s = getStrings();

  // ALIGNED LEFT footer drawing helper
  auto drawButtonFooter = [&](const char *f7, const char *f8, const char *f6)
  {
    u8g2.setFont(s.fontSmall);
    const char *sep = " - ";
    int x = 0;

    drawText(u8g2, x, 62, f7);
    x += getTextWidth(u8g2, f7);
    drawText(u8g2, x, 62, sep);
    x += getTextWidth(u8g2, sep);
    drawText(u8g2, x, 62, f8);
    x += getTextWidth(u8g2, f8);
    drawText(u8g2, x, 62, sep);
    x += getTextWidth(u8g2, sep);
    drawText(u8g2, x, 62, f6);
  };

  if (currentState == STATE_MENU_HOME)
  {
    u8g2.setFont(s.fontMenu);
    drawText(u8g2, 0, 11, s.scaleTitle);

    // 3-Row Centered Display: Selected item is ALWAYS on row 2 (index 1 of loop)
    for (int i = 0; i < 3; i++)
    {
      // i = 0 (Row 1: Previous), i = 1 (Row 2: Centered/Selected), i = 2 (Row 3: Next)
      int itemIdx = (menuIndex + i - 1 + 10) % 10;

      int rowY = 24 + (i * 12);
      drawText(u8g2, 0, rowY, (itemIdx == menuIndex) ? ">" : " ");

      char menuLine[35];
      if (itemIdx == 0)
        snprintf(menuLine, sizeof(menuLine), s.menuUnits, isLbs ? s.unitLbs : s.unitGrams);
      else if (itemIdx == 1)
        snprintf(menuLine, sizeof(menuLine), s.menuBattery, isNiMH ? s.batNimh : s.batAlkaline);
      else if (itemIdx == 2)
        snprintf(menuLine, sizeof(menuLine), s.menuTareMode, tareResetsTimer ? s.tareReset : s.tareTare);
      else if (itemIdx == 3)
        snprintf(menuLine, sizeof(menuLine), s.menuContrast, contrastValues[contrastIndex]);
      else if (itemIdx == 4)
        snprintf(menuLine, sizeof(menuLine), "%s", s.menuButtonAssign);
      else if (itemIdx == 5)
        snprintf(menuLine, sizeof(menuLine), "%s", s.menuCalibration);
      else if (itemIdx == 6)
      {
        const char *modeStr;
        if (batteryDisplayMode == 0)
          modeStr = s.batVolts;
        else if (batteryDisplayMode == 1)
          modeStr = s.batPct;
        else if (batteryDisplayMode == 2)
          modeStr = s.batBoth;
        else if (batteryDisplayMode == 3)
          modeStr = "No";
        else
          modeStr = "REBEL COFFEE SCALE";

        snprintf(menuLine, sizeof(menuLine), s.menuBatDisp, modeStr);
      }
      else if (itemIdx == 7)
      {
        const char *sleepStr = (autoSleepIndex == 0) ? s.sleep10m : (autoSleepIndex == 1) ? s.sleep20m
                                                                                        : (autoSleepIndex == 2)   ? s.sleep1h
                                                                                                                  : s.sleepOff;
        snprintf(menuLine, sizeof(menuLine), s.menuAutoSleep, sleepStr);
      }
      else if (itemIdx == 8)
      {
        const char *measStr = (measuringModeIndex == 0) ? "Smooth" : "Jittery";
        snprintf(menuLine, sizeof(menuLine), "Measuring: %s", measStr);
      }
      else if (itemIdx == 9)
      {
        snprintf(menuLine, sizeof(menuLine), "LANG: %s", s.langName);
      }

      drawText(u8g2, 12, rowY, menuLine);
    }

    drawButtonFooter(s.scroll, s.back, s.enter);
    u8g2.sendBuffer();
    return;
  }

  else if (currentState == STATE_CONFIRM_CALIBRATION)
  {
    u8g2.setFont(s.fontSmall);
    char calDisplay[32];
    snprintf(calDisplay, sizeof(calDisplay), s.calFactor, calibrationFactor);
    drawText(u8g2, 0, 6, calDisplay);

    u8g2.setFont(s.fontMain);
    drawText(u8g2, 0, 22, s.confirmCalibTitle1);
    drawText(u8g2, 0, 36, s.confirmCalibTitle2);
    drawButtonFooter(s.reset, s.back, s.yes);
    u8g2.sendBuffer();
    return;
  }
  else if (currentState == STATE_CONFIRM_DEFAULTS)
  {
    u8g2.setFont(s.fontMain);
    drawText(u8g2, 0, 18, s.mapButtonsTitle1);
    drawText(u8g2, 0, 32, s.mapButtonsTitle2);
    drawButtonFooter(s.setBtn, s.back, s.defaultBtn);
    u8g2.sendBuffer();
    return;
  }
  else if (currentState >= STATE_MAP_TARE && currentState <= STATE_MAP_TIME)
  {
    u8g2.setFont(s.fontMain);
    drawText(u8g2, 0, 16, s.pressBtnFor);
    if (currentState == STATE_MAP_TARE)
      drawText(u8g2, 0, 30, s.actionTare);
    else if (currentState == STATE_MAP_AUTO)
      drawText(u8g2, 0, 30, s.actionAuto);

    auto getMapLabelAct = [&](int actionIndex)
    {
      if (actionIndex == 0)
        return s.actionTime;
      if (actionIndex == 1)
        return s.actionAuto;
      if (actionIndex == 2)
        return s.actionTare;
      return "--";
    };

    char l7[16], l8[16], l6[16];
    snprintf(l7, sizeof(l7), "P7:%s", getMapLabelAct(userMapping[0] == 0 ? 0 : (userMapping[1] == 0 ? 1 : (userMapping[2] == 0 ? 2 : -1))));
    snprintf(l8, sizeof(l8), "P8:%s", getMapLabelAct(userMapping[0] == 1 ? 0 : (userMapping[1] == 1 ? 1 : (userMapping[2] == 1 ? 2 : -1))));
    snprintf(l6, sizeof(l6), "P6:%s", getMapLabelAct(userMapping[0] == 2 ? 0 : (userMapping[1] == 2 ? 1 : (userMapping[2] == 2 ? 2 : -1))));
    drawButtonFooter(l7, l8, l6);
    u8g2.sendBuffer();
    return;
  }
  else if (currentState == STATE_CAL_STEP1_EMPTY)
  {
    u8g2.setFont(s.fontSmall);
    drawText(u8g2, 0, 20, s.calStep1_1);
    drawText(u8g2, 0, 34, s.calStep1_2);
    drawButtonFooter("---", s.cancel, s.next);
    u8g2.sendBuffer();
    return;
  }
  else if (currentState == STATE_CAL_STEP2_PLACE_WT)
  {
    u8g2.setFont(s.fontSmall);
    uint8_t factoryFlagSet = EEPROM.read(40);
    if (factoryFlagSet == 0xA5) {
          drawText(u8g2, 0, 20, s.calStep2_1);
    } else {
      drawText(u8g2, 0, 20, s.calStep2_1_factory);
    }
    drawText(u8g2, 0, 34, s.calStep2_2);
    drawButtonFooter("---", s.cancel, s.next);
    u8g2.sendBuffer();
    return;
  }
  else if (currentState == STATE_CAL_STEP3_MEASURE)
  {
    u8g2.setFont(s.fontMain);
    drawText(u8g2, 0, 32, s.measuring);
    u8g2.sendBuffer();
    return;
  }
  else if (currentState == STATE_CAL_DONE)
  {
    u8g2.setFont(s.fontMain);
    drawText(u8g2, 0, 32, s.calibrated);
    u8g2.sendBuffer();
    return;
  }

  // MAIN SCALE DISPLAY
  u8g2.setFont(s.fontSmall);

  if (timerRunning)
  {
    u8g2.drawTriangle(0, 1, 0, 13, 9, 7);
  }
  else if (autoStartEnabled)
  {
    drawText(u8g2, 0, 6, s.autoStart);
  }

  char batDisplayStr[25] = "";
  if (batteryInitialized && smoothedBatteryV <= 2.25f)
  {
    char vBuf[8];
    dtostrf(smoothedBatteryV, 1, 2, vBuf);
    snprintf(batDisplayStr, sizeof(batDisplayStr), "%s (%s%s)", s.batLow, vBuf, s.batVoltsUnit);
  }
  else if (batteryDisplayMode == 3)
  {
    batDisplayStr[0] = '\0';
  }
  else if (batteryDisplayMode == 4)
  {
    snprintf(batDisplayStr, sizeof(batDisplayStr), "REBEL COFFEE SCALE");
  }
  else if (batteryInitialized)
  {
    int batPct = 0;
    if (isNiMH)
    {
      if (smoothedBatteryV >= 2.70f)
        batPct = 100;
      else if (smoothedBatteryV >= 2.55f)
        batPct = 90;
      else if (smoothedBatteryV >= 2.45f)
        batPct = 75;
      else if (smoothedBatteryV >= 2.35f)
        batPct = 50;
      else if (smoothedBatteryV >= 2.25f)
        batPct = 30;
      else
        batPct = 0;
    }
    else
    {
      if (smoothedBatteryV >= 3.05f)
        batPct = 100;
      else if (smoothedBatteryV >= 2.90f)
        batPct = 90;
      else if (smoothedBatteryV >= 2.75f)
        batPct = 75;
      else if (smoothedBatteryV >= 2.60f)
        batPct = 50;
      else if (smoothedBatteryV >= 2.45f)
        batPct = 30;
      else if (smoothedBatteryV >= 2.30f)
        batPct = 15;
      else if (smoothedBatteryV >= 2.15f)
        batPct = 5;
      else
        batPct = 0;
    }

    char vBuf[8];
    dtostrf(smoothedBatteryV, 1, 2, vBuf);

    if (batteryDisplayMode == BAT_SHOW_VOLTS)
    {
      snprintf(batDisplayStr, sizeof(batDisplayStr), "%s%s", vBuf, s.batVoltsUnit);
    }
    else if (batteryDisplayMode == BAT_SHOW_PCT)
    {
      snprintf(batDisplayStr, sizeof(batDisplayStr), "%d%%", batPct);
    }
    else
    {
      snprintf(batDisplayStr, sizeof(batDisplayStr), "(%s%s) %d%%", vBuf, s.batVoltsUnit, batPct);
    }
  }

  int batWidth = getTextWidth(u8g2, batDisplayStr);
  drawText(u8g2, 128 - batWidth, 6, batDisplayStr);

  int mainY = 37;
  int labelY = 58;

  unsigned long elapsed = (timerRunning) ? (millis() - timerStartMillis) / 1000 : 0;
  unsigned int hours = elapsed / 3600;
  unsigned int minutes = (elapsed % 3600) / 60;
  unsigned int seconds = elapsed % 60;

  bool isWarning = (absoluteWeightGrams > 3000.0f);
  bool isOverload = (absoluteWeightGrams > 4500.0f);

  if (currentTareState != TARE_IDLE)
  {
    u8g2.setFont(s.fontMain);
    if (currentTareState == TARE_SETTLING)
    {
      drawText(u8g2, 0, 35, tareResetsTimer ? s.tareReset : s.tareTare);
    }
  }
  else if (isOverload)
  {
    u8g2.setFont(isUkrainian ? u8g2_font_7x13_t_cyrillic : u8g2_font_7x14_tr);
    const char *heavyStr = s.tooHeavy;
    int hWidth = getTextWidth(u8g2, heavyStr);
    drawText(u8g2, (128 - hWidth) / 2, mainY - 2, heavyStr);
  }
  else
  {
    if (isWarning)
    {
      u8g2.setFont(isUkrainian ? u8g2_font_7x13_t_cyrillic : u8g2_font_7x14_tr);
      drawText(u8g2, 0, mainY - 2, s.warning);
    }
    else
    {
      char tStr[16];
      if (hours > 0)
      {
        u8g2.setFont(s.fontTimerSmall);
        snprintf(tStr, sizeof(tStr), "%u:%02u:%02u", hours, minutes, seconds);
      }
      else
      {
        u8g2.setFont(s.fontTimerLarge);
        snprintf(tStr, sizeof(tStr), "%02u:%02u", minutes, seconds);
      }
      u8g2.drawStr(0, mainY, tStr);
    }

    float calcWeight = isLbs ? (displayWeight * 0.00220462f) : displayWeight;

    if (hours > 0 || isWarning)
    {
      u8g2.setFont(s.fontTimerSmall);
    }
    else
    {
      u8g2.setFont(s.fontTimerLarge);
    }

    char wStr[15];
    if (isLbs)
    {
      dtostrf(calcWeight, 1, 3, wStr);
    }
    else if (autoStartEnabled)
    {
      dtostrf(calcWeight, 1, 0, wStr);
    }
    else
    {
      int decimals = (abs(displayWeight) >= 1000.0f) ? 0 : 1;
      dtostrf(calcWeight, 1, decimals, wStr);
    }

    int wWidth = u8g2.getStrWidth(wStr);
    u8g2.drawStr(128 - wWidth, mainY, wStr);
  }

  u8g2.setFont(s.fontSmall);
  const char *actionNames[3] = {s.actionTime, s.actionAuto, s.actionTare};

  int act7 = (userMapping[0] == 0) ? 0 : ((userMapping[1] == 0) ? 1 : 2);
  int act8 = (userMapping[0] == 1) ? 0 : ((userMapping[1] == 1) ? 1 : 2);
  int act6 = (userMapping[0] == 2) ? 0 : ((userMapping[1] == 2) ? 1 : 2);

  const char *sep = " - ";
  int currentX = 0;

  drawText(u8g2, currentX, labelY, actionNames[act7]);
  currentX += getTextWidth(u8g2, actionNames[act7]);
  drawText(u8g2, currentX, labelY, sep);
  currentX += getTextWidth(u8g2, sep);
  drawText(u8g2, currentX, labelY, actionNames[act8]);
  currentX += getTextWidth(u8g2, actionNames[act8]);
  drawText(u8g2, currentX, labelY, sep);
  currentX += getTextWidth(u8g2, sep);
  drawText(u8g2, currentX, labelY, actionNames[act6]);

  u8g2.sendBuffer();
}

void enterDeepSleep()
{
  u8g2.setPowerSave(1);
  myScale.powerDown();

  for (int i = 0; i < 3; i++)
  {
    gpio_set_dormant_irq_enabled(buttonPins[i], IO_BANK0_DORMANT_WAKE_INTE0_GPIO0_LEVEL_LOW_BITS, true);
  }

  xosc_dormant();

  for (int i = 0; i < 3; i++)
  {
    gpio_set_dormant_irq_enabled(buttonPins[i], IO_BANK0_DORMANT_WAKE_INTE0_GPIO0_LEVEL_LOW_BITS, false);
    gpio_acknowledge_irq(buttonPins[i], IO_BANK0_DORMANT_WAKE_INTE0_GPIO0_LEVEL_LOW_BITS);
  }

  myScale.powerUp();
  myScale.calculateZeroOffset(4);
  u8g2.setPowerSave(0);

  resetInactivityTimer();
}

void setOledBrightness(uint8_t mode)
{
  switch (mode)
  {
  case 0:
    u8g2.sendF("ca", 0xD9, 0x11);
    u8g2.sendF("ca", 0xDB, 0x00);
    u8g2.setContrast(0);
    break;
  case 1:
    u8g2.sendF("ca", 0xD9, 0x22);
    u8g2.sendF("ca", 0xDB, 0x10);
    u8g2.setContrast(5);
    break;
  case 2:
    u8g2.sendF("ca", 0xD9, 0x22);
    u8g2.sendF("ca", 0xDB, 0x20);
    u8g2.setContrast(15);
    break;
  case 3:
    u8g2.sendF("ca", 0xD9, 0x44);
    u8g2.sendF("ca", 0xDB, 0x30);
    u8g2.setContrast(40);
    break;
  case 4:
    u8g2.sendF("ca", 0xD9, 0x82);
    u8g2.sendF("ca", 0xDB, 0x34);
    u8g2.setContrast(120);
    break;
  case 5:
    u8g2.sendF("ca", 0xD9, 0xF1);
    u8g2.sendF("ca", 0xDB, 0x34);
    u8g2.setContrast(255);
    break;
  }
}

void loadSettings()
{
  EEPROM.begin(256);
  float storedFactor = 0;
  EEPROM.get(0, storedFactor);
  if (!isnan(storedFactor) && abs(storedFactor) > 10.0f)
  {
    calibrationFactor = storedFactor;
  }

  int validMarker = EEPROM.read(10);
  if (validMarker == 42)
  {
    userMapping[0] = EEPROM.read(11);
    userMapping[1] = EEPROM.read(12);
    userMapping[2] = EEPROM.read(13);
    isLbs = EEPROM.read(14);
    isNiMH = EEPROM.read(15);
    tareResetsTimer = EEPROM.read(16);

    uint8_t storedBatMode = EEPROM.read(18);
    batteryDisplayMode = (storedBatMode < 5) ? storedBatMode : BAT_SHOW_BOTH;

    uint8_t storedSleepIdx = EEPROM.read(19);
    autoSleepIndex = (storedSleepIdx < 4) ? storedSleepIdx : 1;

    uint8_t storedContrast = EEPROM.read(17);
    contrastIndex = (storedContrast < 6) ? storedContrast : 3;

    uint8_t storedMeasMode = EEPROM.read(21);
    measuringModeIndex = (storedMeasMode < 2) ? storedMeasMode : 0;

    isUkrainian = EEPROM.read(20);
  }
}

void saveSettings()
{
  float currentFactor = 0;
  EEPROM.get(0, currentFactor);

  uint8_t currentMarker = EEPROM.read(10);
  uint8_t currentMap0 = EEPROM.read(11);
  uint8_t currentMap1 = EEPROM.read(12);
  uint8_t currentMap2 = EEPROM.read(13);
  bool currentLbs = EEPROM.read(14);
  bool currentNiMH = EEPROM.read(15);
  bool currentTare = EEPROM.read(16);
  uint8_t currentCont = EEPROM.read(17);
  uint8_t currentBatMode = EEPROM.read(18);
  uint8_t currentSleepIdx = EEPROM.read(19);
  uint8_t currentMeasMode = EEPROM.read(21);
  bool currentLang = EEPROM.read(20);

  bool needsUpdate = false;
  if (abs(currentFactor - calibrationFactor) > 0.001f)
    needsUpdate = true;
  if (currentMarker != 42)
    needsUpdate = true;
  if (currentBatMode != batteryDisplayMode)
    needsUpdate = true;
  if (currentMap0 != userMapping[0])
    needsUpdate = true;
  if (currentMap1 != userMapping[1])
    needsUpdate = true;
  if (currentMap2 != userMapping[2])
    needsUpdate = true;
  if (currentLbs != isLbs)
    needsUpdate = true;
  if (currentNiMH != isNiMH)
    needsUpdate = true;
  if (currentTare != tareResetsTimer)
    needsUpdate = true;
  if (currentCont != contrastIndex)
    needsUpdate = true;
  if (currentSleepIdx != autoSleepIndex)
    needsUpdate = true;
  if (currentMeasMode != measuringModeIndex)
    needsUpdate = true;
  if (currentLang != isUkrainian)
    needsUpdate = true;

  if (needsUpdate)
  {
    EEPROM.put(0, calibrationFactor);
    EEPROM.write(10, 42);
    EEPROM.write(11, userMapping[0]);
    EEPROM.write(12, userMapping[1]);
    EEPROM.write(13, userMapping[2]);
    EEPROM.write(14, isLbs);
    EEPROM.write(15, isNiMH);
    EEPROM.write(16, tareResetsTimer);
    EEPROM.write(17, contrastIndex);
    EEPROM.write(18, batteryDisplayMode);
    EEPROM.write(19, autoSleepIndex);
    EEPROM.write(20, isUkrainian);
    EEPROM.write(21, measuringModeIndex);
    EEPROM.commit();
  }
}