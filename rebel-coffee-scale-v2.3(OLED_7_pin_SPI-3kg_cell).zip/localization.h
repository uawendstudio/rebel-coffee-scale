#ifndef LOCALIZATION_H
#define LOCALIZATION_H

#include <U8g2lib.h>

// Global Language Toggle State: false = EN, true = UA
extern bool isUkrainian;

// UI Strings Structure
struct LocalizedStrings
{
    // Fonts
    const uint8_t *fontMain;
    const uint8_t *fontMenu;
    const uint8_t *fontSmall;
    const uint8_t *fontTimerLarge;
    const uint8_t *fontTimerSmall;
    const uint8_t *fontHeavy;

    // Text Content
    const char *scaleTitle;
    const char *unitLbs;
    const char *unitGrams;
    const char *batNimh;
    const char *batAlkaline;
    const char *tareReset;
    const char *tareTare;
    const char *menuUnits;
    const char *menuBattery;
    const char *menuTareMode;
    const char *menuContrast;
    const char *menuButtonAssign;
    const char *menuCalibration;
    const char *menuBatDisp;
    const char *menuAutoSleep;
    const char *scroll;
    const char *back;
    const char *enter;
    const char *calFactor;
    const char *confirmCalibTitle1;
    const char *confirmCalibTitle2;
    const char *reset;
    const char *yes;
    const char *mapButtonsTitle1;
    const char *mapButtonsTitle2;
    const char *defaultBtn;
    const char *pressBtnFor;
    const char *calStep1_1;
    const char *calStep1_2;
    const char *cancel;
    const char *next;
    const char *calStep2_1;
    const char *calStep2_1_factory;
    const char *calStep2_2;
    const char *measuring;
    const char *calibrated;
    const char *restored;
    const char *autoStart;
    const char *tooHeavy;
    const char *warning;
    const char *langName;
    const char *batLow;
    const char *actionTime;
    const char *actionAuto;
    const char *actionTare;
    const char *setBtn;
    const char *batVolts;
    const char *batPct;
    const char *batBoth;
    const char *sleep10m;
    const char *sleep20m;
    const char *sleep1h;
    const char *sleepOff;
    const char *settling;
    const char *sampling;
    const char *batVoltsUnit;
};

// Helper text rendering function handling EN vs UA routing and fonts
inline void drawText(U8G2 &u8g2, int x, int y, const char *str)
{
    if (isUkrainian)
    {
        u8g2.drawUTF8(x, y, str);
    }
    else
    {
        u8g2.drawStr(x, y, str);
    }
}

// Helper text width function to correctly handle UTF-8 cyrillic character widths
inline int getTextWidth(U8G2 &u8g2, const char *str)
{
    if (isUkrainian)
    {
        return u8g2.getUTF8Width(str);
    }
    else
    {
        return u8g2.getStrWidth(str);
    }
}

// Ukrainian Strings & Cyrillic Fonts Mapping
const LocalizedStrings stringsUA = {
    // Fonts (Cyrillic supported equivalents)
    u8g2_font_6x13_t_cyrillic, // fontMain
    u8g2_font_6x13_t_cyrillic, // fontMenu
    u8g2_font_5x8_t_cyrillic,  // fontSmall
    u8g2_font_fub17_tf,        // fontTimerLarge
    u8g2_font_fub11_tf,        // fontTimerSmall
    u8g2_font_helvB12_tf,      // fontHeavy

    // Translations
    "ВАГИ REBEL v2.31",       // scaleTitle
    "ФУНТИ",                   // unitLbs
    "ГРАМИ",                   // unitGrams
    "NiMH",                    // batNimh
    "ЛУЖНА",                   // batAlkaline
    "СКИНУТИ",                 // tareReset
    "ТАРУВАТИ",                // tareTare
    "ОДИНИЦІ: %s",             // menuUnits
    "БАТАРЕЯ: %s",             // menuBattery
    "ТАРА: %s",                // menuTareMode
    "КОНТРАСТ: %d",            // menuContrast
    "ПРИЗНАЧ. КНОП.",          // menuButtonAssign
    "КАЛІБРУВАННЯ",            // menuCalibration
    "ІНДИК. БАТ: %s",          // menuBatDisp
    "АВТО СОН: %s",            // menuAutoSleep
    "ГОРТАТИ",                 // scroll
    "НАЗАД",                   // back
    "ВХІД",                    // enter
    "коеф. калібр: %.5f",      // calFactor
    "Ви дійсно хочете",        // confirmCalibTitle1
    "калібрувати?",            // confirmCalibTitle2
    "СКИНУТИ",                 // reset
    "ТАК",                     // yes
    "Призначення кнопок",      // mapButtonsTitle1
    "Конфігурація",            // mapButtonsTitle2
    "СТАНДАРТ",                // defaultBtn
    "НАТИСНІТЬ КНОПКУ ДЛЯ:",   // pressBtnFor
    "1. ОЧИСТІТЬ ПЛАТФОРМУ",   // calStep1_1
    "   ПОТІМ НАТИСНІТЬ ДАЛІ", // calStep1_2
    "СКАСУВАТИ",               // cancel
    "ДАЛІ",                    // next
    "2. ПОСТАВТЕ 100Г",        // calStep2_1
    "2. ПОСТАВТЕ 200Г",        // calStep2_1_factory
    "   ПОТІМ НАТИСНІТЬ ДАЛІ", // calStep2_2
    "ВИМІРЮВАННЯ...",          // measuring
    "СКАЛІБРОВАНО!",           // calibrated
    "ВІДНОВЛЕНО!",             // restored
    "Авто старт",              // autoStart
    "ЗАВАЖКО",                 // tooHeavy
    "ПОПЕРЕДЖЕННЯ!",           // warning
    "УКР",                     // langName
    "НИЗЬКИЙ",                 // batLow
    "ЧАС",                     // actionTime
    "АВТО",                    // actionAuto
    "ТАРА",                    // actionTare
    "ЗМІНИТИ",                 // setBtn
    "ВОЛЬТИ",                  // batVolts
    "%",                       // batPct
    "ВСЕ",                     // batBoth
    "10хв",                    // sleep10m
    "20хв",                    // sleep20m
    "1год",                    // sleep1h
    "ВИМК",                    // sleepOff
    "СТАБІЛІЗАЦІЯ...",         // settling
    "ЗБИРАННЯ ДАНИХ...",       // sampling
    "В"                        // batVoltsUnit
};

// English Strings & Standard Fonts Mapping
const LocalizedStrings stringsEN = {
    // Fonts
    u8g2_font_6x12_tr,        // fontMain
    u8g2_font_6x12_tr,        // fontMenu
    u8g2_font_squeezed_b6_tr, // fontSmall
    u8g2_font_fub17_tn,       // fontTimerLarge
    u8g2_font_fub11_tn,       // fontTimerSmall
    u8g2_font_helvB12_tr,     // fontHeavy

    // Translations
    "REBEL SCALE V2.31", // scaleTitle
    "LBS",                // unitLbs
    "GRAMS",              // unitGrams
    "NiMH",               // batNimh
    "ALKALINE",           // alkaline
    "RESET",              // tareReset
    "TARE",               // tareTare
    "UNITS: %s",          // menuUnits
    "BATTERY: %s",        // menuBattery
    "TARE MODE: %s",      // menuTareMode
    "CONTRAST: %d",       // menuContrast
    "BUTTON ASSIGN",      // menuButtonAssign
    "CALIBRATION",        // calibration
    "BAT DISP: %s",       // menuBatDisp
    "AUTO SLEEP: %s",     // menuAutoSleep
    "SCROLL",             // scroll
    "BACK",               // back
    "ENTER",              // enter
    "cal factor: %.5f",   // calFactor
    "Sure you want to",   // confirmCalibTitle1
    "calibrate?",         // confirmCalibTitle2
    "RESET",              // reset
    "YES",                // yes
    "Map Buttons",        // mapButtonsTitle1
    "Configuration",      // mapButtonsTitle2
    "DEFAULT",            // defaultBtn
    "PRESS BUTTON FOR:",  // pressBtnFor
    "1. Clear platform",  // calStep1_1
    "   then press next", // calStep1_2
    "CANCEL",             // cancel
    "NEXT",               // next
    "2. Place 100g",      // calStep2_1
    "2. Place 200g",      // calStep2_1_factory
    "   then press next", // calStep2_2
    "MEASURING...",       // measuring
    "CALIBRATED!",        // calibrated
    "RESTORED!",          // restored
    "Auto",               // autoStart
    "TOO HEAVY",          // tooHeavy
    "WARNING!",           // warning
    "ENG",                // langName
    "LOW",                // batLow
    "Time",               // actionTime
    "Auto",               // actionAuto
    "Tare",               // actionTare
    "SET",                // setBtn
    "VOLTS",              // batVolts
    "PCT",                // batPct
    "BOTH",               // batBoth
    "10M",                // sleep10m
    "20M",                // sleep20m
    "1H",                 // sleep1h
    "OFF",                // sleepOff
    "SETTLING...",        // settling
    "SAMPLING...",        // sampling
    "v"                   // batVoltsUnit
};

inline const LocalizedStrings &getStrings()
{
    return isUkrainian ? stringsUA : stringsEN;
}

#endif